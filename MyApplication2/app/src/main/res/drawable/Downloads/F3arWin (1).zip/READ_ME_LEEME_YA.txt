If the tool will not open, move it to C: \ F3ar.
If it still does not open, go to the ToolBin folder and open the F3arRa1n.exe

Si la herramienta no abre, muévela a C:\F3ar.
Si aun así no abre, entra a la carpeta ToolBin y abre el F3arRa1n.exe
